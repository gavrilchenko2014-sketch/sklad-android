package ua.sklad.app.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "items")
data class Item(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val sku: String,
    val category: String,
    val unit: String,
    val quantity: Double,
    val minQuantity: Double,
    val price: Double,
    val location: String,
    val note: String = "",
    val updatedAt: Long = System.currentTimeMillis()
) {
    val isLow: Boolean get() = quantity <= minQuantity
}

@Entity(
    tableName = "movements",
    foreignKeys = [
        ForeignKey(
            entity = Item::class,
            parentColumns = ["id"],
            childColumns = ["itemId"],
            onDelete = ForeignKey.CASCADE
        )
    ],
    indices = [Index("itemId")]
)
data class Movement(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val itemId: Long,
    val itemName: String,
    val type: String,
    val amount: Double,
    val balanceAfter: Double,
    val note: String,
    val createdAt: Long = System.currentTimeMillis()
)

object MoveType {
    const val IN = "IN"
    const val OUT = "OUT"
    const val SET = "SET"
}
