package ua.sklad.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Ink = Color(0xFF09090B)
val Panel = Color(0xFF141418)
val PanelHigh = Color(0xFF1C1C22)
val Copper = Color(0xFFC4A484)
val Silver = Color(0xFFE7E8EC)
val Mist = Color(0xFF9A9AA3)
val Danger = Color(0xFFE07A5F)
val Ok = Color(0xFF8FBF9F)

private val colors = darkColorScheme(
    primary = Copper,
    onPrimary = Ink,
    secondary = Silver,
    background = Ink,
    onBackground = Silver,
    surface = Panel,
    onSurface = Silver,
    surfaceVariant = PanelHigh,
    onSurfaceVariant = Mist,
    error = Danger
)

@Composable
fun SkladTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = colors, content = content)
}
