package ua.sklad.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Inventory2
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch
import ua.sklad.app.data.Item
import ua.sklad.app.data.MoveType
import ua.sklad.app.data.Movement
import ua.sklad.app.ui.theme.Copper
import ua.sklad.app.ui.theme.Danger
import ua.sklad.app.ui.theme.Mist
import ua.sklad.app.ui.theme.Ok
import ua.sklad.app.ui.theme.PanelHigh
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SkladApp(vm: SkladViewModel = viewModel()) {
    val items by vm.items.collectAsStateWithLifecycle()
    val low by vm.low.collectAsStateWithLifecycle()
    val movements by vm.movements.collectAsStateWithLifecycle()
    var tab by remember { mutableIntStateOf(0) }
    var query by remember { mutableStateOf("") }
    var editor by remember { mutableStateOf<Item?>(null) }
    var creating by remember { mutableStateOf(false) }
    var moving by remember { mutableStateOf<Item?>(null) }
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    val shown = items.filter {
        val q = query.trim().lowercase()
        q.isEmpty() || it.name.lowercase().contains(q) ||
            it.sku.lowercase().contains(q) ||
            it.location.lowercase().contains(q) ||
            it.category.lowercase().contains(q)
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        snackbarHost = { SnackbarHost(snack) },
        floatingActionButton = {
            if (tab == 0) {
                FloatingActionButton(
                    onClick = { creating = true },
                    containerColor = Copper,
                    contentColor = MaterialTheme.colorScheme.onPrimary
                ) { Icon(Icons.Outlined.Add, contentDescription = "Новый товар") }
            }
        },
        bottomBar = {
            NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                NavigationBarItem(
                    selected = tab == 0,
                    onClick = { tab = 0 },
                    icon = { Icon(Icons.Outlined.Inventory2, null) },
                    label = { Text("Склад") }
                )
                NavigationBarItem(
                    selected = tab == 1,
                    onClick = { tab = 1 },
                    icon = { Icon(Icons.Outlined.WarningAmber, null) },
                    label = { Text("Мало ${if (low.isEmpty()) "" else low.size}") }
                )
                NavigationBarItem(
                    selected = tab == 2,
                    onClick = { tab = 2 },
                    icon = { Icon(Icons.Outlined.Search, null) },
                    label = { Text("Журнал") }
                )
            }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding)) {
            Text(
                when (tab) {
                    1 -> "Пора докупить"
                    2 -> "Движения"
                    else -> "Склад"
                },
                modifier = Modifier.padding(start = 20.dp, top = 18.dp, end = 20.dp),
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                when (tab) {
                    1 -> if (low.isEmpty()) "Всё выше минимума" else "${low.size} позиций на исходе"
                    2 -> if (movements.isEmpty()) "Пока тихо" else "${movements.size} записей"
                    else -> "${items.size} позиций · ${money(items.sumOf { it.quantity * it.price })}"
                },
                modifier = Modifier.padding(start = 20.dp, top = 2.dp, end = 20.dp, bottom = 12.dp),
                color = Mist
            )
            if (tab == 0) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                    singleLine = true,
                    placeholder = { Text("Название, артикул, место") },
                    leadingIcon = { Icon(Icons.Outlined.Search, null) }
                )
                Spacer(Modifier.height(8.dp))
            }
            when (tab) {
                0 -> ItemList(shown, onOpen = { editor = it }, onMove = { moving = it }, onDelete = {
                    vm.delete(it.id)
                    scope.launch { snack.showSnackbar("Убрала «${it.name}»") }
                })
                1 -> ItemList(low, onOpen = { editor = it }, onMove = { moving = it }, onDelete = { vm.delete(it.id) })
                else -> MovementList(movements)
            }
        }
    }

    if (creating) {
        ItemDialog(
            title = "Новая позиция",
            initial = Item(name = "", sku = "", category = "", unit = "шт", quantity = 0.0, minQuantity = 0.0, price = 0.0, location = ""),
            onDismiss = { creating = false },
            onSave = {
                vm.save(it)
                creating = false
            }
        )
    }
    editor?.let { item ->
        ItemDialog(
            title = "Карточка",
            initial = item,
            onDismiss = { editor = null },
            onSave = {
                vm.save(it)
                editor = null
            }
        )
    }
    moving?.let { item ->
        MoveDialog(
            item = item,
            onDismiss = { moving = null },
            onConfirm = { type, amount, note ->
                vm.move(item.id, type, amount, note)
                moving = null
            }
        )
    }
}

@Composable
private fun ItemList(
    items: List<Item>,
    onOpen: (Item) -> Unit,
    onMove: (Item) -> Unit,
    onDelete: (Item) -> Unit
) {
    if (items.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Пусто. Добавь первую позицию.", color = Mist)
        }
        return
    }
    LazyColumn(
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(items, key = { it.id }) { item ->
            Column(
                Modifier
                    .fillMaxWidth()
                    .background(PanelHigh, RoundedCornerShape(16.dp))
                    .clickable { onOpen(item) }
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(item.name, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(
                            listOf(item.sku, item.category, item.location).filter { it.isNotBlank() }.joinToString(" · "),
                            color = Mist,
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                    IconButton(onClick = { onDelete(item) }) {
                        Icon(Icons.Outlined.Delete, contentDescription = "Удалить", tint = Mist)
                    }
                }
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        qty(item.quantity) + " " + item.unit,
                        color = if (item.isLow) Danger else Ok,
                        fontWeight = FontWeight.Medium
                    )
                    if (item.isLow) {
                        Spacer(Modifier.width(8.dp))
                        Text("ниже ${qty(item.minQuantity)}", color = Danger, style = MaterialTheme.typography.bodySmall)
                    }
                    Spacer(Modifier.weight(1f))
                    Text(money(item.price), color = Mist, style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.width(8.dp))
                    TextButton(onClick = { onMove(item) }) { Text("Движение") }
                }
            }
        }
    }
}

@Composable
private fun MovementList(list: List<Movement>) {
    if (list.isEmpty()) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Журнал пуст. Сделай приход или расход.", color = Mist)
        }
        return
    }
    val fmt = remember { SimpleDateFormat("d MMM, HH:mm", Locale("ru")) }
    LazyColumn(contentPadding = PaddingValues(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(list, key = { it.id }) { m ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .background(PanelHigh, RoundedCornerShape(14.dp))
                    .padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text(m.itemName, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        buildString {
                            append(fmt.format(Date(m.createdAt)))
                            if (m.note.isNotBlank()) append(" · ").append(m.note)
                        },
                        color = Mist,
                        style = MaterialTheme.typography.bodySmall
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        when (m.type) {
                            MoveType.IN -> "+${qty(m.amount)}"
                            MoveType.OUT -> "−${qty(m.amount)}"
                            else -> "→ ${qty(m.balanceAfter)}"
                        },
                        color = when (m.type) {
                            MoveType.IN -> Ok
                            MoveType.OUT -> Danger
                            else -> Copper
                        },
                        fontWeight = FontWeight.SemiBold
                    )
                    Text("остаток ${qty(m.balanceAfter)}", color = Mist, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun ItemDialog(title: String, initial: Item, onDismiss: () -> Unit, onSave: (Item) -> Unit) {
    var name by remember { mutableStateOf(initial.name) }
    var sku by remember { mutableStateOf(initial.sku) }
    var category by remember { mutableStateOf(initial.category) }
    var unit by remember { mutableStateOf(initial.unit) }
    var qty by remember { mutableStateOf(num(initial.quantity)) }
    var min by remember { mutableStateOf(num(initial.minQuantity)) }
    var price by remember { mutableStateOf(num(initial.price)) }
    var place by remember { mutableStateOf(initial.location) }
    var note by remember { mutableStateOf(initial.note) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Field("Название", name) { name = it }
                Field("Артикул", sku) { sku = it }
                Field("Категория", category) { category = it }
                Field("Единица", unit) { unit = it }
                Field("Остаток", qty) { qty = it }
                Field("Минимум", min) { min = it }
                Field("Цена, грн", price) { price = it }
                Field("Место", place) { place = it }
                Field("Заметка", note) { note = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (name.isBlank()) return@TextButton
                onSave(
                    initial.copy(
                        name = name.trim(),
                        sku = sku.trim(),
                        category = category.trim(),
                        unit = unit.ifBlank { "шт" }.trim(),
                        quantity = qty.toDoubleOrNull() ?: 0.0,
                        minQuantity = min.toDoubleOrNull() ?: 0.0,
                        price = price.toDoubleOrNull() ?: 0.0,
                        location = place.trim(),
                        note = note.trim()
                    )
                )
            }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
private fun MoveDialog(item: Item, onDismiss: () -> Unit, onConfirm: (String, Double, String) -> Unit) {
    var type by remember { mutableStateOf(MoveType.IN) }
    var amount by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(item.name) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Сейчас ${qty(item.quantity)} ${item.unit}", color = Mist)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    TypeChip("Приход", type == MoveType.IN) { type = MoveType.IN }
                    TypeChip("Расход", type == MoveType.OUT) { type = MoveType.OUT }
                    TypeChip("Факт", type == MoveType.SET) { type = MoveType.SET }
                }
                Field(if (type == MoveType.SET) "Поставить остаток" else "Количество", amount) { amount = it }
                Field("Заметка", note) { note = it }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val n = amount.replace(',', '.').toDoubleOrNull() ?: return@TextButton
                if (n < 0) return@TextButton
                onConfirm(type, n, note)
            }) { Text("Провести") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
private fun TypeChip(label: String, on: Boolean, click: () -> Unit) {
    Text(
        label,
        modifier = Modifier
            .background(if (on) Copper else PanelHigh, RoundedCornerShape(20.dp))
            .clickable(onClick = click)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        color = if (on) MaterialTheme.colorScheme.onPrimary else Mist
    )
}

@Composable
private fun Field(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(value = value, onValueChange = onChange, label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth())
}

private fun qty(n: Double): String =
    if (n % 1.0 == 0.0) n.toLong().toString() else String.format(Locale.US, "%.2f", n)

private fun num(n: Double): String = if (n == 0.0) "" else qty(n)

private fun money(n: Double): String = String.format(Locale("ru"), "%.0f грн", n)
