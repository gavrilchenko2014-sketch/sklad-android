package ua.sklad.app.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(entities = [Item::class, Movement::class], version = 1, exportSchema = false)
abstract class SkladDatabase : RoomDatabase() {
    abstract fun dao(): SkladDao

    companion object {
        @Volatile private var instance: SkladDatabase? = null

        fun get(context: Context): SkladDatabase {
            return instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    SkladDatabase::class.java,
                    "sklad.db"
                ).addCallback(seed).build().also { instance = it }
            }
        }

        private val seed = object : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                instance?.let { database ->
                    CoroutineScope(Dispatchers.IO).launch {
                        val dao = database.dao()
                        if (dao.countItems() > 0) return@launch
                        samples.forEach { dao.insertItem(it) }
                    }
                }
            }
        }

        private val samples = listOf(
            Item(name = "Кабель ВВГнг 3×2.5", sku = "CAB-325", category = "Электрика", unit = "м", quantity = 86.0, minQuantity = 30.0, price = 42.0, location = "A-1"),
            Item(name = "Саморезы 3.5×35", sku = "SCR-3535", category = "Крепёж", unit = "уп", quantity = 4.0, minQuantity = 6.0, price = 78.0, location = "B-3"),
            Item(name = "Краска интерьерная белая", sku = "PNT-W10", category = "Отделка", unit = "л", quantity = 12.5, minQuantity = 5.0, price = 165.0, location = "C-2"),
            Item(name = "Гофра 20 мм", sku = "PPR-20", category = "Электрика", unit = "м", quantity = 18.0, minQuantity = 25.0, price = 9.5, location = "A-2"),
            Item(name = "Автомат 16А", sku = "MCB-16", category = "Электрика", unit = "шт", quantity = 7.0, minQuantity = 4.0, price = 95.0, location = "A-4")
        )
    }
}
