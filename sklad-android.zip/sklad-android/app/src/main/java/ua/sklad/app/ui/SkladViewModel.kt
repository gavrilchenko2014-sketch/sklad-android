package ua.sklad.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import ua.sklad.app.data.Item
import ua.sklad.app.data.Movement
import ua.sklad.app.data.SkladDatabase
import ua.sklad.app.data.SkladRepository

class SkladViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = SkladRepository(SkladDatabase.get(app).dao())

    val items: StateFlow<List<Item>> = repo.items()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val low: StateFlow<List<Item>> = repo.low()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())
    val movements: StateFlow<List<Movement>> = repo.movements()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun save(item: Item) = viewModelScope.launch { repo.save(item) }
    fun delete(id: Long) = viewModelScope.launch { repo.delete(id) }
    fun move(itemId: Long, type: String, amount: Double, note: String) =
        viewModelScope.launch { repo.move(itemId, type, amount, note) }
}
