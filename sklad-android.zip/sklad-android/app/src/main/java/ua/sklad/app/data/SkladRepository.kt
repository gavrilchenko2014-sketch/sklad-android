package ua.sklad.app.data

import kotlinx.coroutines.flow.Flow

class SkladRepository(private val dao: SkladDao) {
    fun items(): Flow<List<Item>> = dao.observeItems()
    fun low(): Flow<List<Item>> = dao.observeLow()
    fun movements(): Flow<List<Movement>> = dao.observeMovements()

    suspend fun save(item: Item) {
        val now = System.currentTimeMillis()
        if (item.id == 0L) {
            dao.insertItem(item.copy(updatedAt = now))
        } else {
            dao.updateItem(item.copy(updatedAt = now))
        }
    }

    suspend fun delete(id: Long) = dao.deleteItem(id)

    suspend fun move(itemId: Long, type: String, amount: Double, note: String) {
        val item = dao.item(itemId) ?: return
        val next = when (type) {
            MoveType.IN -> item.quantity + amount
            MoveType.OUT -> (item.quantity - amount).coerceAtLeast(0.0)
            MoveType.SET -> amount
            else -> item.quantity
        }
        val delta = when (type) {
            MoveType.SET -> kotlin.math.abs(next - item.quantity)
            else -> amount
        }
        dao.updateItem(item.copy(quantity = next, updatedAt = System.currentTimeMillis()))
        dao.insertMovement(
            Movement(
                itemId = item.id,
                itemName = item.name,
                type = type,
                amount = delta,
                balanceAfter = next,
                note = note.trim()
            )
        )
    }
}
