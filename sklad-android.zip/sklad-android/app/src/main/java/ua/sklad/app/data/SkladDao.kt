package ua.sklad.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface SkladDao {
    @Query("SELECT * FROM items ORDER BY name COLLATE NOCASE")
    fun observeItems(): Flow<List<Item>>

    @Query("SELECT * FROM items WHERE quantity <= minQuantity ORDER BY name COLLATE NOCASE")
    fun observeLow(): Flow<List<Item>>

    @Query("SELECT * FROM movements ORDER BY createdAt DESC")
    fun observeMovements(): Flow<List<Movement>>

    @Query("SELECT * FROM items WHERE id = :id")
    suspend fun item(id: Long): Item?

    @Insert
    suspend fun insertItem(item: Item): Long

    @Update
    suspend fun updateItem(item: Item)

    @Query("DELETE FROM items WHERE id = :id")
    suspend fun deleteItem(id: Long)

    @Insert
    suspend fun insertMovement(movement: Movement)

    @Query("SELECT COUNT(*) FROM items")
    suspend fun countItems(): Int
}
